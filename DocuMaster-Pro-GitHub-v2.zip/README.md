# DocuMaster Pro v2 (Standalone Adobe Acrobat Alternative)

Cross-platform PDF & Word Suite built for **Windows PC** and **Android** with an **English UI**.
Now includes **built-in offline PDF & Word processing** + **Drag & Drop support**!

## Features
1. **Drag & Drop Files Directly** onto the application window.
2. **Word to PDF & PDF to Word Conversion** (Offline native engine + optional Python backend).
3. **Edit PDF Text & Annotations** with built-in interactive PDF Viewer.
4. **Draw & Place Digital Signatures** directly onto PDF pages.
5. **Merge & Split PDF Files** with instant local file saving.
6. **Automated GitHub Actions CI/CD** (`.github/workflows/main.yml`) that builds both Android `.apk` and Windows `.exe` artifacts automatically.
