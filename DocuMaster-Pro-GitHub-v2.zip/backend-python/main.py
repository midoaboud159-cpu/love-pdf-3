from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse
import shutil
import os
import fitz
from pypdf import PdfWriter
from pdf2docx import Converter

app = FastAPI(title="DocuMaster Pro Engine")
UPLOAD_DIR = "temp_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/pdf-to-word")
async def pdf_to_word(file: UploadFile = File(...)):
    pdf_path = os.path.join(UPLOAD_DIR, file.filename)
    docx_path = pdf_path.replace(".pdf", ".docx")
    with open(pdf_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    cv = Converter(pdf_path)
    cv.convert(docx_path, start=0, end=None)
    cv.close()
    return FileResponse(docx_path, filename=os.path.basename(docx_path))
